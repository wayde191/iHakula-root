/**
  *@author: Wayde Sun
  *@Time: 2009.10.16
  *@Version: 1.0
  *  User test cases example
  */
 
 gi.gdog.gunit.gdogUnit.defineTests("gdog.tests", function(t, gunit){
 
	t.testPrograme2 = function(){
		gunit.assertNotEquals("gi.test.App1", "gi.testAppw1");
	}
 });